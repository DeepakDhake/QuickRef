package com.avaloq.Controller;

import com.avaloq.Pojos.Employee;
import com.avaloq.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@Validated
public class EmployeeController {
    @Autowired
    private EmployeeService empServ;

    public EmployeeController() {
        System.out.println("In Employee Constructor");
    }

    @GetMapping("/employees")
    List<Employee> listEmp(){
        return empServ.getAllEmployee();
    }

    @PostMapping("/add")
    Employee addNewEmp(@RequestBody Employee transEmp) {
        return empServ.addNewEmployee(transEmp);
    }

    @GetMapping("/{empId}")
    Optional<Employee> findEmp(@PathVariable Long empId) {
        return empServ.getEmpById(empId);
    }

    @PutMapping("/update")
    public Employee updateEmpDetails(@RequestBody Employee detachedEmp) {

        System.out.println("in update emp " + detachedEmp);// id : not null
        return empServ.updateEmpDetails(detachedEmp);
    }

    @DeleteMapping("/{empId}")
    String delEmp(@PathVariable Long empId) {
        return empServ.deleteEmp(empId);
    }

}