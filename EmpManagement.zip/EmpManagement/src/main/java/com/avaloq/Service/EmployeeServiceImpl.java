package com.avaloq.Service;

import com.avaloq.Pojos.Employee;
import com.avaloq.Repository.EmployeeRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository empRepo;
    @Override
    public List<Employee> getAllEmployee() {
        return empRepo.findAll();
    }

    @Override
    public Employee addNewEmployee(Employee newEmp) {
        return empRepo.save(newEmp);
    }

    @Override
    public Employee updateEmpDetails(Employee upEmp) {
        return empRepo.save(upEmp);
    }

    @Override
    public String deleteEmp(Long empId) {
        String mesg = "Employee Failed to deleted";
        if (empRepo.existsById(empId)) {
            empRepo.deleteById(empId);
            mesg = "Emp with Id = " + empId + " deleted";
        }
        return mesg;
    }

    @Override
    public Optional<Employee> getEmpById(Long empId) {
        return empRepo.findById(empId);
    }
}
