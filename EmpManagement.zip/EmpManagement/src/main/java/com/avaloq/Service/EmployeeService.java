package com.avaloq.Service;

import com.avaloq.Pojos.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    List<Employee> getAllEmployee();
    Employee addNewEmployee(Employee newEmp);
    Employee updateEmpDetails(Employee upEmp);
    String deleteEmp(Long empId);
    Optional<Employee> getEmpById(Long empId);
}
